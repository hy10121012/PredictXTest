java -cp predictX-test-1.0-SNAPSHOT.jar yi.work.predictx.PredicXApplicationStarter 

